<?php
header('Content-Type: application/json');
$servername = "47.112.31.17";
$username = "dobby";
$password = "9b823f3c83b8";
$dbname = "dobby";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die(json_encode(['error' => '连接失败: ' . $conn->connect_error]));
}

$player_id = isset($_POST['player_id']) ? $_POST['player_id'] : '';

$sql = "
    SELECT pw.work_id, pw.count, zp.zp, zp.zzm, zp.zzid
    FROM player_works pw
    JOIN zp ON pw.work_id = zp.ID
    WHERE pw.player_id = ?
";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $player_id); 
$stmt->execute();
$result = $stmt->get_result();

$works = [];
while ($row = $result->fetch_assoc()) {
    $works[] = [
        'work_id' => $row['work_id'],
        'count' => $row['count'],
        'zp' => $row['zp'],
        'zzm' => $row['zzm'],
        'zzid' => $row['zzid']
    ];
}
echo json_encode($works);
$stmt->close();
$conn->close();
?>