<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET');
header('Access-Control-Allow-Headers: Content-Type');

$servername = "47.112.31.17";
$username = "dobby";
$password = "9b823f3c83b8";
$dbname = "dobby";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // ����zp��
    $conn->exec("CREATE TABLE IF NOT EXISTS zp (
        id INT AUTO_INCREMENT PRIMARY KEY,
        zzm VARCHAR(255) NOT NULL,
        zzid VARCHAR(255) NOT NULL,
        zp VARCHAR(255) NOT NULL
    )");

    // ����player_works�����洢�����Ʒ����
    $conn->exec("CREATE TABLE IF NOT EXISTS player_works (
        id INT AUTO_INCREMENT PRIMARY KEY,
        player_id VARCHAR(255) NOT NULL,
        work_id INT NOT NULL,
        count INT DEFAULT 0,
        FOREIGN KEY (work_id) REFERENCES zp(id)
    )");

    // ���dobby���Ƿ�����works�У����û��������
    $stmt = $conn->query("SHOW COLUMNS FROM dobby LIKE 'works'");
    $columnExists = $stmt->fetch();
    if (!$columnExists) {
        $conn->exec("ALTER TABLE dobby ADD COLUMN works TEXT");
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $data = json_decode(file_get_contents('php://input'), true);
        if (isset($data['type']) && $data['type'] === 'work') {
            // ������Ʒ��ʯ
            $playerId = $data['id'];
            $workId = $data['work_id'];

            $stmt = $conn->prepare("SELECT count FROM player_works WHERE player_id = :player_id AND work_id = :work_id");
            $stmt->bindParam(':player_id', $playerId);
            $stmt->bindParam(':work_id', $workId);
            $stmt->execute();
            $existingWork = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($existingWork) {
                $stmt = $conn->prepare("UPDATE player_works SET count = count + 1 WHERE player_id = :player_id AND work_id = :work_id");
                $stmt->bindParam(':player_id', $playerId);
                $stmt->bindParam(':work_id', $workId);
                $stmt->execute();
            } else {
                $stmt = $conn->prepare("INSERT INTO player_works (player_id, work_id, count) VALUES (:player_id, :work_id, 1)");
                $stmt->bindParam(':player_id', $playerId);
                $stmt->bindParam(':work_id', $workId);
                $stmt->execute();
            }

            // ����dobby���е�works�ֶ�
            $stmt = $conn->prepare("SELECT works FROM dobby WHERE id = :id");
            $stmt->bindParam(':id', $playerId);
            $stmt->execute();
            $existingWorks = $stmt->fetch(PDO::FETCH_ASSOC);
            $works = $existingWorks && $existingWorks['works'] ? json_decode($existingWorks['works'], true) : [];
            $works[$workId] = ($works[$workId] ?? 0) + 1;
            
            $stmt = $conn->prepare("UPDATE dobby SET works = :works WHERE id = :id");
            $stmt->bindParam(':id', $playerId);
            $worksJson = json_encode($works);
            $stmt->bindParam(':works', $worksJson);
            $stmt->execute();

            echo json_encode(['status' => 'success', 'message' => 'Work mineral saved']);
        } else {
            // ԭ�еķ��������߼�
            $playerId = $data['id'];
            $score = $data['score'];

            $stmt = $conn->prepare("SELECT score FROM dobby WHERE id = :id");
            $stmt->bindParam(':id', $playerId);
            $stmt->execute();
            $existingScore = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($existingScore) {
                if ($existingScore['score'] < $score) {
                    $stmt = $conn->prepare("UPDATE dobby SET score = :score, play_time = NOW() WHERE id = :id");
                    $stmt->bindParam(':id', $playerId);
                    $stmt->bindParam(':score', $score, PDO::PARAM_INT);
                    $stmt->execute();
                    echo json_encode(['status' => 'success', 'message' => 'Score updated']);
                } else {
                    echo json_encode(['status' => 'success', 'message' => 'Score not updated: not higher than existing score']);
                }
            } else {
                $stmt = $conn->prepare("INSERT INTO dobby (id, score, play_time, works) VALUES (:id, :score, NOW(), '{}')");
                $stmt->bindParam(':id', $playerId);
                $stmt->bindParam(':score', $score, PDO::PARAM_INT);
                $stmt->execute();
                echo json_encode(['status' => 'success', 'message' => 'New score saved']);
            }
        }
    } elseif ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['type']) && $_GET['type'] === 'works') {
        // ��ȡ������Ʒ��ʯ
        $stmt = $conn->query("SELECT id, zzm, zzid, zp FROM zp");
        $works = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($works);
    } elseif ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['type']) && $_GET['type'] === 'player_works' && isset($_GET['id'])) {
        // ��ȡ���ӵ�е���Ʒ����
        $playerId = $_GET['id'];
        $stmt = $conn->prepare("SELECT work_id, count FROM player_works WHERE player_id = :player_id");
        $stmt->bindParam(':player_id', $playerId);
        $stmt->execute();
        $playerWorks = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($playerWorks);
    } elseif ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
        // ԭ�еĻ�ȡ��ҷ����߼�
        $playerId = $_GET['id'];
        $stmt = $conn->prepare("SELECT id, score FROM dobby WHERE id = :id");
        $stmt->bindParam(':id', $playerId);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($result);
    } elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
        // ԭ�е����а��߼�
        $stmt = $conn->query("SELECT id, score FROM dobby ORDER BY score DESC LIMIT 10");
        $leaderboard = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($leaderboard);
    }
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>