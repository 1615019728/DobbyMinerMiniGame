<?php
header('Content-Type: application/json');
$servername = "47.112.31.17";
$username = "dobby";
$password = "9b823f3c83b8";
$dbname = "dobby";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die(json_encode(['error' => '连接失败: ' . $conn->connect_error]));
}
$sql = "SELECT ID, zp, zzm, zzid FROM zp";
$result = $conn->query($sql);

$works = [];
while ($row = $result->fetch_assoc()) {
    $works[] = [
        'ID' => $row['ID'],
        'zp' => $row['zp'],
        'zzm' => $row['zzm'],
        'zzid' => $row['zzid']
    ];
}
echo json_encode($works);
$conn->close();
?>